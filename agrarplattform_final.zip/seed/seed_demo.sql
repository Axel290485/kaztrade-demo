
-- Benutzer (Admin, Verkäufer, Käufer)
INSERT INTO users (email, password_hash, role) VALUES
('admin@test.com', crypt('test123', gen_salt('bf')), 'admin'),
('seller@test.com', crypt('test123', gen_salt('bf')), 'seller'),
('buyer@test.com', crypt('test123', gen_salt('bf')), 'buyer');

-- Produkte (Agrarprodukte in mehreren Einheiten)
INSERT INTO products (title, description, category, unit, price, seller_id)
VALUES
('Weizen aus Kasachstan', 'Bio-Weizen aus Nordkasachstan, hochwertig', 'Getreide', 'kg', 0.35, 2),
('Hirse Premium', 'Goldene Hirse aus Almaty-Region', 'Getreide', 'kg', 0.55, 2),
('Sonnenblumenöl', 'Kaltgepresst, 100% natürlich', 'Öle', 'l', 1.50, 2),
('Kartoffeln', 'Frische Speisekartoffeln direkt vom Bauernhof', 'Gemüse', 'kg', 0.25, 2);
